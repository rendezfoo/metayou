### It is a dark time for the Rebellion. 

The taxation of trade routes to outlying star systems is in dispute. Rebel spaceships, striking from a hidden base, have won their first victory against the evil Galactic Empire.

In a stunning move, the fiendish droid leader has swept into the Republic capital and kidnapped the leader of the Galactic Senate.

Leia has sent her most daring pilot on a secret mission to Jakku, where an old ally has discovered a clue to Luke's whereabouts ...
